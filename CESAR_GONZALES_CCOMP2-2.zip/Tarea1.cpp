#include <iostream>
using namespace std;

int main() {
    int radio;
    cout << "Ingrese el radio de la circunferencia (en metros): " << endl;
    cin >> radio;

    cout << "El diámetro de la circunferencia es: " << (radio * 2) << "m" << endl;
    cout << "\nEl perímetro sería: " << 3.14159 * (radio * 2) << "m" << endl;
    cout << "\nEl área sería: " << 3.14159 * (radio * radio) << "m^2" << endl;

    return 0;
}