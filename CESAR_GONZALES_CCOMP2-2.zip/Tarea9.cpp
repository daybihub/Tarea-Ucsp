#include <iostream>
using namespace std;

int main() {
    int numero;

    cout << "Ingrese un numero con 4 digitos: " << endl;
    cin >> numero;

    int division1 = numero / 1000;
    int division2 = (numero % 1000) / 100;
    int division3 = (numero % 100) / 10;
    int division4 = numero % 10;

    cout << division4 << "; " << division3 << "; " << division2 << "; " << division1 << endl;

    return 0;
}