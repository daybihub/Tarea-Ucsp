#include <iostream>
using namespace std;

int main() {
    char palabra;

    cout << "Ingrese la letra, numero o simbolo: " << endl;
    cin >> palabra;
    cout << "Ingrese el valor de ese caracter y los 10 caracteres siguientes en la lista ASCII\n" << endl;
    int numero = int(palabra);

    for (int x = 1; x <= 10; x++) {
        cout << "\nEl valor en ASCII serìa: " << numero << endl;
        cout << "El caracter serìa: " << char(numero) << endl;
        numero = numero + 1;
    }

    return 0;
}