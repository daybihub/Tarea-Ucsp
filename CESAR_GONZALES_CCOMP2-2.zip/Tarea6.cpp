#include <iostream>
using namespace std;

int main() {
    int numero1;
    int numero2;
    int numero3;

    cout << "Ingrese el 1er numero: " << endl;
    cin >> numero1;
    cout << "Ingrese el 2do numero: " << endl;
    cin >> numero2;
    cout << "Ingrese el 3er numero: " << endl;
    cin >> numero3;

    if (numero3 % numero1 == 0)
        cout << "El numero " << numero1 << " es factor(divisor) de " << numero3 << endl;
    else
        cout << "El numero " << numero1 << " no es factor(divisor) de " << numero3 << endl;

    if (numero2 % numero1 == 0)
        cout << "El numero " << numero2 << " es factor(divisor) de " << numero3 << endl;
    else
        cout << "El numero " << numero2 << " no es factor(divisor) de " << numero3 << endl;

    return 0;
}