#include <iostream>
#include <list>
using namespace std;

int main() {
    list<int> lista{0, 1, 2, 3, 4, 5};

    cout << "Face length\tSurface area\tVolume" << endl;
    cout << "of cube (cm)\tof cube (cm^2)\tof cube (cm^3)" << endl;

    for (auto x : lista)
        cout << x << "\t\t" << (x * x) * 6 << "\t\t" << x * x * x << endl;

    return 0;
}