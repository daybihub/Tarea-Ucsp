#include <iostream>
using namespace std;

int main() {
    int numero1;
    int numero2;

    cout << "Ingrese el 1er numero: " << endl;
    cin >> numero1;
    cout << "Ingrese el 2do numero: " << endl;
    cin >> numero2;

    if (numero1 % 2 == 0)
        cout << "El numero " << numero1 << " es par" << endl;
    else
        cout << "El numero " << numero1 << " es impar" << endl;

    if (numero2 % 2 == 0)
        cout << "El numero " << numero2 << " es par" << endl;
    else
        cout << "El numero " << numero2 << " es impar" << endl;

    int numero3 = numero1 + numero2;
    if (numero3 % 2 == 0)
        cout << "La suma de " << numero1 << " y " << numero2 << " es par" << endl;
    else
        cout << "La suma de " << numero1 << " y " << numero2 << " es impar" << endl;

    return 0;
}