#include <iostream>
using namespace std;

int main() {
    string palabras2 = "Y el menor numero es: ";
    string palabras1 = "El mayor numero es: ";
    int num1;
    int num2;
    int num3;
    int num4;
    int num5;

    cout << "Ingrese el 1er numero:" << endl;
    cin >> num1;

    cout << "Ingrese el 2do numero:" << endl;
    cin >> num2;

    cout << "Ingrese 3er numero:" << endl;
    cin >> num3;

    cout << "Ingrese 4to numero:" << endl;
    cin >> num4;

    cout << "Ingrese 5to numero:" << endl;
    cin >> num5;

    if (num1 >= num2 && num1 >= num3 && num1 >= num4 && num1 >= num5)
        cout << palabras1 << num1 << endl;

    else if (num2 >= num1 && num2 >= num3 && num2 >= num4 && num2 >= num5)
        cout << palabras1 << num2 << endl;

    else if (num3 >= num2 && num3 >= num1 && num3 >= num4 && num3 >= num5)
        cout << palabras1 << num3 << endl;

    else if (num4 >= num2 && num4 >= num3 && num4 >= num1 && num4 >= num5)
        cout << palabras1 << num4 << endl;

    else if (num5 >= num2 && num5 >= num3 && num5 >= num4 && num5 >= num1)
        cout << palabras1 << num5 << endl;

    if (num1 <= num2 && num1 <= num3 && num1 <= num4 && num1 <= num5)
        cout << palabras2 << num1 << endl;

    else if (num2 <= num1 && num2 <= num3 && num2 <= num4 && num2 <= num5)
        cout << palabras2 << num2 << endl;

    else if (num3 <= num2 && num3 <= num1 && num3 <= num4 && num3 <= num5)
        cout << palabras2 << num3 << endl;

    else if (num4 <= num2 && num4 <= num3 && num4 <= num1 && num4 <= num5)
        cout << palabras2 << num4 << endl;

    else if (num5 <= num2 && num5 <= num3 && num5 <= num4 && num5 <= num1)
        cout << palabras2 << num5 << endl;

    return 0;
}